const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('companionSim', {
  platform: process.platform,
  version: '0.3.0',
  /** Active window TITLE only (never screen contents). Null if unavailable. */
  getActiveWindow: () => ipcRenderer.invoke('get-active-window')
});

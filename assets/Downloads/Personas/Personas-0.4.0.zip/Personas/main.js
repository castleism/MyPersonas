const { app, BrowserWindow, session, ipcMain } = require('electron');
const path = require('path');
const { execFile } = require('child_process');

/* ---- active-window detection (titles only, never contents) ---- */

const PS_SCRIPT = `
Add-Type @"
using System;using System.Runtime.InteropServices;using System.Text;
public class FG {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h, StringBuilder t, int c);
}
"@
$h=[FG]::GetForegroundWindow();$sb=New-Object System.Text.StringBuilder 512;[void][FG]::GetWindowText($h,$sb,512);$sb.ToString()`;

function getActiveWindowTitle() {
  return new Promise((resolve) => {
    if (process.platform === 'win32') {
      execFile('powershell', ['-NoProfile', '-NonInteractive', '-Command', PS_SCRIPT],
        { timeout: 5000 }, (err, stdout) => resolve(err ? null : (stdout || '').trim() || null));
    } else if (process.platform === 'darwin') {
      execFile('osascript', ['-e', 'tell application "System Events" to get name of first process whose frontmost is true'],
        { timeout: 5000 }, (err, stdout) => resolve(err ? null : (stdout || '').trim() || null));
    } else {
      resolve(null); // linux: not implemented; focus mode falls back to manual topic
    }
  });
}

ipcMain.handle('get-active-window', () => getActiveWindowTitle());

/* ---- window ---- */

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 640,
    title: 'Personas',
    backgroundColor: '#12101c',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

app.whenReady().then(() => {
  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    callback({ responseHeaders: details.responseHeaders });
  });

  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

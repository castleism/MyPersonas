/* =========================================================================
 * extensions-builtin.js — the four bundled extensions.
 * Each is a normal extension manifest; users can remove them, and their
 * source doubles as reference for writing custom ones.
 * NOTE: extension code below is plain ES5-ish and uses string concat, no
 * backticks, so it can live safely inside these template literals.
 * ========================================================================= */

const EXT_BASE_CSS = `
<style>
  * { box-sizing: border-box; margin: 0; }
  body { font-family: "Segoe UI", system-ui, sans-serif; background: #17142a; color: #e8e4ff; padding: 18px; font-size: 14px; }
  h1 { font-size: 18px; margin-bottom: 4px; }
  h2 { font-size: 14px; margin: 14px 0 6px; color: #b9b0e8; }
  .muted { color: #8f88b8; font-size: 12px; }
  button { background: #8b6cf0; color: #fff; border: 0; border-radius: 8px; padding: 7px 14px; cursor: pointer; font-size: 13px; margin: 2px 4px 2px 0; }
  button.sec { background: #262242; border: 1px solid #3d3568; }
  input, textarea, select { width: 100%; background: #141127; color: #e8e4ff; border: 1px solid #3d3568; border-radius: 8px; padding: 8px 10px; font-size: 13px; margin: 4px 0; font-family: inherit; }
  .card { background: #201c38; border: 1px solid #322c55; border-radius: 10px; padding: 12px; margin: 8px 0; }
  .row { display: flex; gap: 8px; align-items: center; }
  .row > * { flex: 1; }
  .out { white-space: pre-wrap; background: #141127; border-radius: 8px; padding: 10px; margin-top: 8px; min-height: 40px; }
  .bar { height: 8px; background: #141127; border-radius: 4px; overflow: hidden; }
  .bar > div { height: 100%; background: #8b6cf0; }
  .pill { display: inline-block; background: #262242; border: 1px solid #3d3568; border-radius: 999px; padding: 3px 10px; margin: 2px; cursor: pointer; font-size: 12px; }
  .pill.on { background: #8b6cf0; border-color: #8b6cf0; }
</style>`;

/* shared helper injected into each built-in: companion picker + model input */
const EXT_HELPERS = `
<script>
  function el(id){ return document.getElementById(id); }
  function esc(s){ return String(s).replace(/[&<>"']/g, function(c){ return {"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;","'":"&#39;"}[c]; }); }
  function fillCompanions(selectId){
    ext.listCompanions().then(function(list){
      el(selectId).innerHTML = list.map(function(c){ return '<option value="'+c.id+'">'+esc(c.name)+'</option>'; }).join('');
    });
  }
  function today(){ return new Date().toISOString().slice(0,10); }
</script>`;

const WRITING_PLANNER = {
  id: 'builtin_writing_planner',
  name: 'Writing Planner',
  icon: '📝',
  description: 'Plan writing projects: outlines, word goals, daily progress. AI drafts outlines and critiques your notes; your companion cheers on (or nags about) your progress.',
  html: `<!DOCTYPE html><html><head><title>Writing Planner</title>${EXT_BASE_CSS}</head><body>
<h1>📝 Writing Planner</h1>
<div class="muted">Projects with word goals · AI outlining &amp; critique · progress reports to a companion</div>

<div class="card">
  <div class="row"><input id="np-title" placeholder="New project title" /><input id="np-goal" type="number" placeholder="Word goal (e.g. 50000)" /><button id="np-add">Add</button></div>
</div>
<div id="projects"></div>
${EXT_HELPERS}
<script>
var db = { projects: [] };
ext.storageGet('db').then(function(v){ if (v) db = v; render(); });
function save(){ ext.storageSet('db', db); }

el('np-add').onclick = function(){
  var t = el('np-title').value.trim(); if (!t) return;
  db.projects.push({ id: Math.random().toString(36).slice(2), title: t, goal: parseInt(el('np-goal').value,10) || 0, outline: '', notes: '', log: [] });
  el('np-title').value = ''; el('np-goal').value = '';
  save(); render();
};

function words(p){ return p.log.reduce(function(a,e){ return a + e.words; }, 0); }

function render(){
  var host = el('projects'); host.innerHTML = '';
  db.projects.forEach(function(p){
    var w = words(p), pct = p.goal ? Math.min(100, Math.round(w / p.goal * 100)) : 0;
    var card = document.createElement('div'); card.className = 'card';
    card.innerHTML =
      '<div class="row"><h2 style="flex:2;margin:0">'+esc(p.title)+'</h2><span class="muted">'+w+' / '+(p.goal||'?')+' words ('+pct+'%)</span><button class="sec" data-del>✕</button></div>' +
      '<div class="bar"><div style="width:'+pct+'%"></div></div>' +
      '<h2>Notes / premise</h2><textarea rows="3" data-notes>'+esc(p.notes)+'</textarea>' +
      '<h2>Outline</h2><textarea rows="5" data-outline>'+esc(p.outline)+'</textarea>' +
      '<div class="row"><input data-model placeholder="Model for AI actions (blank = default)" /><button data-ai-outline>AI: draft outline</button><button class="sec" data-ai-critique>AI: critique notes</button></div>' +
      '<div class="out" data-out hidden></div>' +
      '<h2>Log today</h2><div class="row"><input data-words type="number" placeholder="Words written today" /><button data-log>Log</button>' +
      '<select data-comp></select><button class="sec" data-report>Report to companion</button></div>';
    host.appendChild(card);

    var comp = card.querySelector('[data-comp]');
    ext.listCompanions().then(function(list){ comp.innerHTML = list.map(function(c){ return '<option value="'+c.id+'">'+esc(c.name)+'</option>'; }).join(''); });

    card.querySelector('[data-del]').onclick = function(){ db.projects = db.projects.filter(function(x){ return x.id !== p.id; }); save(); render(); };
    card.querySelector('[data-notes]').onchange = function(e){ p.notes = e.target.value; save(); };
    card.querySelector('[data-outline]').onchange = function(e){ p.outline = e.target.value; save(); };
    card.querySelector('[data-log]').onclick = function(){
      var n = parseInt(card.querySelector('[data-words]').value, 10);
      if (n) { p.log.push({ date: today(), words: n }); save(); render(); }
    };
    function runAI(prompt, into){
      var out = card.querySelector('[data-out]'); out.hidden = false; out.textContent = 'Thinking…';
      ext.llm([{ role: 'user', content: prompt }], { model: card.querySelector('[data-model]').value.trim() || undefined })
        .then(function(txt){ out.textContent = txt; if (into) { p.outline = txt; save(); } })
        .catch(function(e){ out.textContent = 'Error: ' + e.message; });
    }
    card.querySelector('[data-ai-outline]').onclick = function(){
      runAI('Draft a chapter-by-chapter outline for a writing project titled "'+p.title+'". Premise/notes: '+(p.notes||'(none)')+'. Be concrete and structured.', true);
    };
    card.querySelector('[data-ai-critique]').onclick = function(){
      runAI('Critique these notes for the writing project "'+p.title+'": strengths, weaknesses, 3 concrete suggestions.\\n\\n'+p.notes, false);
    };
    card.querySelector('[data-report]').onclick = function(){
      var msg = 'Writing update on "'+p.title+'": '+w+' of '+(p.goal||'?')+' words ('+pct+'%).';
      var emo = pct >= 60 ? 'excited' : (pct >= 20 ? 'happy' : 'thinking');
      ext.notifyCompanion(comp.value, msg, emo);
    };
  });
}
</script></body></html>`
};

const SUB_FINDER = {
  id: 'builtin_sub_finder',
  name: 'Subscription Finder',
  icon: '💸',
  description: 'Paste bank/card CSV exports; AI finds recurring charges, forgotten subscriptions, and money-mismanagement patterns. No bank login — your data only goes to the model you pick.',
  html: `<!DOCTYPE html><html><head><title>Subscription Finder</title>${EXT_BASE_CSS}</head><body>
<h1>💸 Subscription Finder</h1>
<div class="muted">Export transactions as CSV from your bank, paste or load below. Transactions are sent only to the model you choose. This is information, not financial advice.</div>

<div class="card">
  <textarea id="csv" rows="8" placeholder="date,description,amount&#10;2026-06-01,NETFLIX.COM,-15.49&#10;2026-06-03,SPOTIFY,-11.99&#10;…"></textarea>
  <div class="row"><input id="file" type="file" accept=".csv,.txt" /><input id="model" placeholder="Model (blank = default)" /></div>
  <button id="analyze">Analyze transactions</button>
  <div class="out" id="out" hidden></div>
</div>
<div class="card">
  <h2>Send findings to a companion</h2>
  <div class="row"><select id="comp"></select><button id="warn" class="sec">Have them warn me</button></div>
  <div class="muted">They'll deliver the top findings in chat and in the lounge.</div>
</div>
${EXT_HELPERS}
<script>
fillCompanions('comp');
var lastSummary = '';

el('file').onchange = function(e){
  var f = e.target.files[0]; if (!f) return;
  var r = new FileReader();
  r.onload = function(){ el('csv').value = String(r.result).slice(0, 100000); };
  r.readAsText(f);
};

el('analyze').onclick = function(){
  var csv = el('csv').value.trim();
  if (!csv) { alert('Paste some transactions first.'); return; }
  var out = el('out'); out.hidden = false; out.textContent = 'Analyzing…';
  var prompt = 'You are a personal-finance analyst. Below are bank/card transactions (CSV). Identify:\\n' +
    '1) All recurring subscriptions (name, amount, cadence, annualized cost)\\n' +
    '2) Likely FORGOTTEN or duplicate subscriptions (small recurring charges, overlapping services)\\n' +
    '3) Money-mismanagement warnings (fees, overdrafts, unusually high categories)\\n' +
    '4) Total potential monthly savings\\n' +
    'Be concrete, use amounts from the data, keep it under 350 words. End with a one-sentence TL;DR line starting with "TLDR:".\\n\\nTRANSACTIONS:\\n' + csv.slice(0, 12000);
  ext.llm([{ role: 'user', content: prompt }], { model: el('model').value.trim() || undefined })
    .then(function(txt){
      out.textContent = txt;
      var m = txt.match(/TLDR:(.*)/i);
      lastSummary = m ? m[1].trim() : txt.slice(0, 300);
    })
    .catch(function(e){ out.textContent = 'Error: ' + e.message; });
};

el('warn').onclick = function(){
  if (!lastSummary) { alert('Run an analysis first.'); return; }
  ext.notifyCompanion(el('comp').value, 'Money check: ' + lastSummary, 'surprised');
};
</script></body></html>`
};

const CHECKIN = {
  id: 'builtin_checkin',
  name: 'Daily Check-in',
  icon: '☀️',
  description: 'Habits, mood, and a daily journal line. Tracks streaks; your companion reacts to how your day went.',
  html: `<!DOCTYPE html><html><head><title>Daily Check-in</title>${EXT_BASE_CSS}</head><body>
<h1>☀️ Daily Check-in</h1>
<div class="card">
  <h2>Habits — tap what you did today</h2>
  <div id="habits"></div>
  <div class="row"><input id="new-habit" placeholder="Add habit (e.g. gym, read 20 min)" /><button id="add-habit">Add</button></div>
</div>
<div class="card">
  <h2>Today's mood</h2>
  <div class="row">
    <select id="mood"><option>great</option><option>good</option><option selected>okay</option><option>rough</option><option>awful</option></select>
    <input id="note" placeholder="One line about today (optional)" />
  </div>
  <div class="row"><select id="comp"></select><button id="checkin">Check in</button></div>
  <div class="muted" id="streak"></div>
</div>
<div class="card"><h2>History</h2><div id="history" class="muted"></div></div>
${EXT_HELPERS}
<script>
var db = { habits: [], entries: [] };
ext.storageGet('db').then(function(v){ if (v) db = v; render(); });
fillCompanions('comp');
function save(){ ext.storageSet('db', db); }

el('add-habit').onclick = function(){
  var n = el('new-habit').value.trim(); if (!n) return;
  db.habits.push({ name: n, dates: [] }); el('new-habit').value = '';
  save(); render();
};

function render(){
  var t = today();
  el('habits').innerHTML = db.habits.map(function(h, i){
    var on = h.dates.indexOf(t) >= 0;
    return '<span class="pill ' + (on ? 'on' : '') + '" data-i="' + i + '">' + esc(h.name) + '</span>';
  }).join('') || '<span class="muted">No habits yet.</span>';
  Array.prototype.forEach.call(el('habits').querySelectorAll('.pill'), function(p){
    p.onclick = function(){
      var h = db.habits[parseInt(p.getAttribute('data-i'), 10)];
      var ix = h.dates.indexOf(t);
      if (ix >= 0) h.dates.splice(ix, 1); else h.dates.push(t);
      save(); render();
    };
  });
  var streak = 0, d = new Date();
  for (;;) {
    var key = d.toISOString().slice(0,10);
    if (db.entries.some(function(e){ return e.date === key; })) { streak++; d.setDate(d.getDate()-1); } else break;
  }
  el('streak').textContent = 'Check-in streak: ' + streak + ' day(s)';
  el('history').innerHTML = db.entries.slice(-14).reverse().map(function(e){
    return e.date + ' — ' + e.mood + (e.note ? ' · ' + esc(e.note) : '');
  }).join('<br>') || 'Nothing yet.';
}

el('checkin').onclick = function(){
  var t = today();
  var mood = el('mood').value, note = el('note').value.trim();
  db.entries = db.entries.filter(function(e){ return e.date !== t; });
  var done = db.habits.filter(function(h){ return h.dates.indexOf(t) >= 0; }).map(function(h){ return h.name; });
  db.entries.push({ date: t, mood: mood, note: note, habits: done });
  save(); render();
  var msg = 'Daily check-in: feeling ' + mood + '.' +
    (done.length ? ' Did: ' + done.join(', ') + '.' : ' No habits logged.') +
    (note ? ' Note: ' + note : '');
  var emo = { great: 'excited', good: 'happy', okay: 'neutral', rough: 'sad', awful: 'sad' }[mood] || 'neutral';
  ext.notifyCompanion(el('comp').value, msg, emo);
};
</script></body></html>`
};

const TEMPLATE_EXT = {
  id: 'builtin_template',
  name: 'Extension Template',
  icon: '🧩',
  description: 'A documented starter showing every API. Copy its source (or ask any AI to write one like it), tweak, and install via paste.',
  html: `<!DOCTYPE html><html><head><title>Extension Template</title>${EXT_BASE_CSS}</head><body>
<h1>🧩 Extension Template</h1>
<div class="muted">An extension is one HTML file. It runs sandboxed and talks to the app via <b>window.ext</b>. Ask an AI: "write me a Personas extension that does X, single HTML file using the window.ext API (llm, storageGet/Set, listCompanions, notifyCompanion, getModels)" — then install it from the Extensions page via Paste.</div>

<div class="card"><h2>1 · ext.llm(messages, {model}) — call your AI models</h2>
  <input id="q" placeholder="Ask anything…" /><button id="ask">Ask</button>
  <div class="out" id="a" hidden></div>
</div>
<div class="card"><h2>2 · ext.storageSet / storageGet — persistent storage</h2>
  <div class="row"><input id="memo" placeholder="A note that survives restarts" /><button id="save-memo">Save</button></div>
  <div class="muted" id="memo-echo"></div>
</div>
<div class="card"><h2>3 · ext.listCompanions + ext.notifyCompanion — talk through a companion</h2>
  <div class="row"><select id="comp"></select><button id="ping">Make them say hi</button></div>
</div>
<div class="card"><h2>4 · ext.getModels — model catalog</h2>
  <button id="models" class="sec">Count available models</button> <span id="mcount" class="muted"></span>
</div>
${EXT_HELPERS}
<script>
fillCompanions('comp');
ext.storageGet('memo').then(function(v){ el('memo-echo').textContent = v ? 'Saved note: ' + v : ''; });

el('ask').onclick = function(){
  var out = el('a'); out.hidden = false; out.textContent = '…';
  ext.llm([{ role: 'user', content: el('q').value }])
    .then(function(t){ out.textContent = t; })
    .catch(function(e){ out.textContent = 'Error: ' + e.message; });
};
el('save-memo').onclick = function(){
  ext.storageSet('memo', el('memo').value).then(function(){ el('memo-echo').textContent = 'Saved note: ' + el('memo').value; });
};
el('ping').onclick = function(){
  ext.notifyCompanion(el('comp').value, 'Hello from the Extension Template! 👋', 'happy');
};
el('models').onclick = function(){
  ext.getModels().then(function(m){ el('mcount').textContent = m.length + ' models'; });
};
</script></body></html>`
};

window.BUILTIN_EXTENSIONS = [WRITING_PLANNER, SUB_FINDER, CHECKIN, TEMPLATE_EXT];

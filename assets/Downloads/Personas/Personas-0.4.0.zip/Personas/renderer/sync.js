/* =========================================================================
 * sync.js — MyPersonas account sync (mypersonas.online / Supabase)
 *
 * Loaded after app.js; uses its top-level bindings (state, save, stage,
 * getCompanion, newCompanionTemplate, SAMPLE_MODELS).
 *
 * Sign in with your MyPersonas account; your owned personas are imported
 * as app personas (create or update, matched by site id). Mapping:
 *   name                       -> name
 *   tagline/bio/purpose/voice/
 *   audience/dont              -> personality prompt
 *   topics + hashtags          -> interests
 *   ai_backend.model           -> model (if set on the site)
 * Visuals (Live2D) stay chosen locally per persona — edit after import.
 * Local fields you set are only overwritten by their site counterparts;
 * Live2D choice, NSFW model, goals and chats are never touched by sync.
 * ========================================================================= */

const MYPERSONAS = {
  url: 'https://nwsqyuucwzihruszocge.supabase.co',
  anonKey: 'sb_publishable_vN6BdSvBKf_yTJt0eeK20w_afKz1Df2'
};

const AccountSync = {
  session: null, // { access_token, refresh_token, user }

  headers(extra) {
    const h = Object.assign({ apikey: MYPERSONAS.anonKey, 'Content-Type': 'application/json' }, extra);
    if (this.session) h.Authorization = 'Bearer ' + this.session.access_token;
    return h;
  },

  async signIn(email, password) {
    const res = await fetch(MYPERSONAS.url + '/auth/v1/token?grant_type=password', {
      method: 'POST',
      headers: { apikey: MYPERSONAS.anonKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error_description || json.msg || 'Sign-in failed');
    this.session = json;
    localStorage.setItem('mypersonas-refresh', json.refresh_token || '');
    return json;
  },

  async refresh() {
    const rt = localStorage.getItem('mypersonas-refresh');
    if (!rt) return false;
    try {
      const res = await fetch(MYPERSONAS.url + '/auth/v1/token?grant_type=refresh_token', {
        method: 'POST',
        headers: { apikey: MYPERSONAS.anonKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: rt })
      });
      const json = await res.json();
      if (!res.ok) return false;
      this.session = json;
      localStorage.setItem('mypersonas-refresh', json.refresh_token || rt);
      return true;
    } catch (e) { return false; }
  },

  signOut() {
    this.session = null;
    localStorage.removeItem('mypersonas-refresh');
  },

  async fetchMyPersonas() {
    if (!this.session) throw new Error('Not signed in');
    const uid = this.session.user && this.session.user.id;
    const res = await fetch(
      MYPERSONAS.url + '/rest/v1/personas?owner=eq.' + uid +
      '&select=id,handle,name,tagline,bio,nsfw,topics,purpose,voice,audience,hashtags,dont,theme,ai_backend:ai_backends(name,base_url,model)',
      { headers: this.headers() }
    );
    if (!res.ok) throw new Error('Fetch failed: ' + res.status + ' ' + (await res.text()).slice(0, 200));
    return await res.json();
  },

  buildPrompt(p) {
    let s = 'You are ' + p.name + (p.handle ? ' (@' + p.handle + ')' : '') + ', one of the user\'s personas from MyPersonas.';
    if (p.tagline) s += '\nTagline: ' + p.tagline;
    if (p.bio) s += '\nBio: ' + p.bio;
    if (p.purpose) s += '\nPurpose: ' + p.purpose;
    if (p.voice) s += '\nVoice/style: ' + p.voice;
    if (p.audience) s += '\nAudience: ' + p.audience;
    if (p.dont) s += '\nNever do: ' + p.dont;
    return s;
  },

  buildInterests(p) {
    const tags = (p.hashtags || '').replace(/#/g, '').trim();
    return [p.topics, tags].filter(Boolean).join(', ');
  },

  /** Import/update site personas as app personas. Returns {created, updated}. */
  async sync() {
    const rows = await this.fetchMyPersonas();
    let created = 0, updated = 0;
    for (const p of rows) {
      let c = state.companions.find(x => x.syncId === p.id);
      if (!c) {
        c = newCompanionTemplate();
        c.syncId = p.id;
        c.live2dUrl = SAMPLE_MODELS[(created + state.companions.length) % 2].url;
        state.companions.push(c);
        created++;
      } else {
        updated++;
      }
      c.name = p.name;
      c.handle = p.handle;
      c.prompt = this.buildPrompt(p);
      c.interests = this.buildInterests(p);
      c.siteNsfw = !!p.nsfw;
      if (p.ai_backend && p.ai_backend.model) c.model = p.ai_backend.model;
    }
    save();
    for (const c of state.companions) if (c.syncId) { await stage.addCompanion(c); stage.rename(c.id, c.name); }
    return { created, updated, total: rows.length };
  }
};

/* ---------------- settings UI wiring ---------------- */

(function initSyncUi() {
  const $s = (id) => document.getElementById(id);
  const status = (t, ok) => { const el = $s('mp-status'); el.textContent = t; el.style.color = ok ? '#7ee787' : ''; };

  $s('btn-mp-sync').addEventListener('click', async () => {
    try {
      status('Signing in…');
      if (!AccountSync.session) {
        const email = $s('mp-email').value.trim();
        const pass = $s('mp-pass').value;
        if (!email || !pass) { status('Enter your MyPersonas email + password.'); return; }
        await AccountSync.signIn(email, pass);
      }
      status('Syncing personas…');
      const r = await AccountSync.sync();
      status('Synced ' + r.total + ' persona(s): ' + r.created + ' new, ' + r.updated + ' updated. Pick their Live2D visuals via Edit.', true);
      $s('mp-pass').value = '';
    } catch (e) { status('Error: ' + e.message); }
  });

  $s('btn-mp-signout').addEventListener('click', () => {
    AccountSync.signOut();
    status('Signed out. Synced personas remain in the app.');
  });

  // silent re-sync on boot if we have a stored session
  AccountSync.refresh().then(async (ok) => {
    if (ok) {
      try {
        const r = await AccountSync.sync();
        status('Auto-synced ' + r.total + ' persona(s) from your account.', true);
      } catch (e) { /* offline or RLS issue — manual sync available */ }
    }
  });
})();

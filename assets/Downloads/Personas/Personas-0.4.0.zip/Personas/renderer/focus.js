/* =========================================================================
 * focus.js — MyPersonas screen-aware focus mode
 *
 * Loaded AFTER app.js so it can use its top-level bindings
 * (state, save, stage, getCompanion, renderMessages, completeOnce,
 *  activeCompanionId, Emotions).
 *
 * While a focus session runs:
 *  - polls the ACTIVE WINDOW TITLE (only the title, never screen contents)
 *    every 20s via the main process
 *  - at a randomized interval, picks the persona whose interests best match
 *    the current topic + recent window titles (weighted by chattiness)
 *  - that persona interjects: a short in-character remark, encouragement,
 *    or an off-task nudge — spoken in the lounge and saved to their chat
 * ========================================================================= */

const OFFTASK_RE = /(youtube|netflix|twitch|tiktok|instagram|reddit|twitter|x\.com|steam|epic games|solitaire|minecraft|fortnite)/i;

const FocusMode = {
  running: false,
  screenAware: true,
  topic: '',
  intervalMin: 5,
  titles: [],            // recent unique window titles
  pollTimer: null,
  nextAt: 0,
  busy: false,

  start(opts) {
    this.topic = opts.topic || '';
    this.intervalMin = opts.intervalMin || 5;
    this.screenAware = !!opts.screenAware;
    this.titles = [];
    this.running = true;
    this.scheduleNext();
    this.pollTimer = setInterval(() => this._tick(), 20000);
    this._tick();
  },

  stop() {
    this.running = false;
    clearInterval(this.pollTimer);
  },

  scheduleNext() {
    const jitter = 0.7 + Math.random() * 0.6;
    this.nextAt = Date.now() + this.intervalMin * 60000 * jitter;
  },

  async _tick() {
    if (!this.running) return;
    if (this.screenAware && window.companionSim && window.companionSim.getActiveWindow) {
      try {
        const t = await window.companionSim.getActiveWindow();
        if (t && !/^personas$/i.test(t.trim())) {
          this.titles = this.titles.filter(x => x !== t);
          this.titles.push(t);
          if (this.titles.length > 5) this.titles.shift();
          FocusUI.setStatus('watching: ' + t.slice(0, 60));
        }
      } catch (e) { /* detection unavailable — manual topic still works */ }
    }
    if (Date.now() >= this.nextAt && !this.busy) {
      this.scheduleNext();
      this.busy = true;
      try { await this.interject(); } catch (e) { console.warn('interjection failed', e); }
      this.busy = false;
    }
  },

  /* pick persona whose interests match current context, weighted by chattiness */
  pickPersona() {
    const context = (this.topic + ' ' + this.titles.join(' ')).toLowerCase();
    const weights = { high: 1.6, normal: 1, low: 0.45, off: 0 };
    let best = null, bestScore = -1;
    for (const c of state.companions) {
      const w = weights[c.chattiness || 'normal'];
      if (w === 0) continue;
      const interests = (c.interests || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
      let score = 0;
      for (const it of interests) if (it && context.includes(it)) score += 2;
      score = (score + Math.random()) * w; // random tiebreak so everyone gets turns
      if (score > bestScore) { bestScore = score; best = c; }
    }
    return best;
  },

  async interject() {
    const c = this.pickPersona();
    if (!c) return;
    const offTask = this.titles.some(t => OFFTASK_RE.test(t));
    const context =
      (this.topic ? 'The user says they are working on: ' + this.topic + '. ' : '') +
      (this.titles.length ? 'Recently active windows on their computer: ' + this.titles.join(' | ') + '. ' : '');

    const system =
      (c.prompt || 'You are ' + c.name + ', a companion persona.') +
      (c.backstory ? '\nBackstory: ' + c.backstory : '') +
      (c.interests ? '\nYour interests: ' + c.interests : '') +
      '\n\nYou are lounging on the user\'s desktop while they study/work. ' + context +
      (offTask
        ? 'They look off-task. Give ONE short, in-character nudge to get back to work (max 35 words). '
        : 'Interject ONE short in-character remark: encouragement, a thought connecting their work to your interests, or a fun relevant fact (max 35 words). ') +
      'Do not greet, do not ask if they need help, no preamble.' +
      Emotions.promptAppendix();

    const raw = await completeOnce(c.model, [
      { role: 'system', content: system },
      { role: 'user', content: '(ambient check-in)' }
    ]);
    const { emotion, cleanText } = Emotions.extractTag(raw);
    if (!cleanText) return;

    c.messages.push({ role: 'assistant', content: cleanText, meta: { model: 'focus mode', emotion: emotion || 'neutral' } });
    save();
    stage.setEmotion(c.id, emotion || (offTask ? 'angry' : 'happy'));
    stage.showBubble(c.id, cleanText, 9000);
    if (activeCompanionId === c.id) renderMessages(c);
  }
};

/* ---------------- focus panel UI ---------------- */

const FocusUI = {
  init() {
    const $f = (id) => document.getElementById(id);
    this.panel = $f('focus-panel');
    this.status = $f('focus-status');

    $f('btn-focus').addEventListener('click', () => this.panel.classList.toggle('hidden'));
    $f('btn-focus-close').addEventListener('click', () => this.panel.classList.add('hidden'));

    $f('btn-focus-toggle').addEventListener('click', () => {
      if (FocusMode.running) {
        FocusMode.stop();
        $f('btn-focus-toggle').textContent = 'Start session';
        $f('btn-focus-toggle').classList.remove('danger');
        this.setStatus('idle');
      } else {
        FocusMode.start({
          topic: $f('focus-topic').value.trim(),
          intervalMin: parseInt($f('focus-interval').value, 10),
          screenAware: $f('focus-screen').checked
        });
        $f('btn-focus-toggle').textContent = 'Stop session';
        $f('btn-focus-toggle').classList.add('danger');
        this.setStatus('session running — personas will chime in');
      }
    });

    if (!(window.companionSim && window.companionSim.platform !== 'linux')) {
      $f('focus-screen').checked = false;
    }
  },
  setStatus(text) { if (this.status) this.status.textContent = text; }
};

FocusUI.init();

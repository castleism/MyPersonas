/* =========================================================================
 * app.js — state, providers, chat, goals, NSFW quick-switch, UI wiring
 * ========================================================================= */

/* ---------------- state & persistence ---------------- */

const DEFAULTS = {
  settings: {
    openrouterKey: '',
    ollamaUrl: '',
    nsfwEnabled: false,
    synopsisModel: ''
  },
  companions: []
};

let state = load();
function load() {
  try {
    const raw = localStorage.getItem('companion-sim');
    if (raw) return Object.assign({}, DEFAULTS, JSON.parse(raw));
  } catch (e) { console.warn('state load failed', e); }
  return JSON.parse(JSON.stringify(DEFAULTS));
}
function save() { localStorage.setItem('companion-sim', JSON.stringify(state)); }
function uid() { return Math.random().toString(36).slice(2, 10); }

let activeCompanionId = null;
let spicyArmed = false;
let modelCatalog = [];

const stage = new CharacterStage();

/* ---------------- element refs ---------------- */
const $ = (id) => document.getElementById(id);
const els = {
  chatPanel: $('chat-panel'), messages: $('messages'), input: $('input'),
  chatName: $('chat-name'), chatMood: $('chat-mood'), goalSelect: $('goal-select'),
  spicyBtn: $('btn-spicy'), spicyIndicator: $('spicy-indicator'), spicyModelName: $('spicy-model-name'),
  backdrop: $('modal-backdrop'),
  mSettings: $('modal-settings'), mCompanion: $('modal-companion'), mGoals: $('modal-goals')
};

/* ---------------- providers ---------------- */

function providerFor(model) {
  return model.startsWith('ollama/') ? 'ollama' : 'openrouter';
}

/**
 * Stream a chat completion. onDelta(textSoFar) fires as tokens arrive.
 * Returns the full text.
 */
async function streamChat({ model, messages, onDelta }) {
  if (providerFor(model) === 'ollama') {
    const base = (state.settings.ollamaUrl || 'http://localhost:11434').replace(/\/$/, '');
    const res = await fetch(base + '/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: model.replace(/^ollama\//, ''), messages, stream: true })
    });
    if (!res.ok) throw new Error('Ollama error ' + res.status + ': ' + (await res.text()).slice(0, 300));
    return await readNdjson(res, (obj) => obj.message && obj.message.content, onDelta);
  }

  if (!state.settings.openrouterKey) throw new Error('No OpenRouter API key set — open Settings.');
  const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + state.settings.openrouterKey,
      'HTTP-Referer': 'https://localhost',
      'X-Title': 'Personas'
    },
    body: JSON.stringify({ model, messages, stream: true })
  });
  if (!res.ok) throw new Error('OpenRouter error ' + res.status + ': ' + (await res.text()).slice(0, 300));
  return await readSse(res, onDelta);
}

async function readSse(res, onDelta) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '', full = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split('\n');
    buf = lines.pop();
    for (const line of lines) {
      const t = line.trim();
      if (!t.startsWith('data:')) continue;
      const data = t.slice(5).trim();
      if (data === '[DONE]') continue;
      try {
        const delta = JSON.parse(data).choices?.[0]?.delta?.content;
        if (delta) { full += delta; onDelta(full); }
      } catch (e) { /* keep-alive comment or partial */ }
    }
  }
  return full;
}

async function readNdjson(res, pick, onDelta) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '', full = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split('\n');
    buf = lines.pop();
    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const piece = pick(JSON.parse(line));
        if (piece) { full += piece; onDelta(full); }
      } catch (e) { /* partial */ }
    }
  }
  return full;
}

/** Non-streaming single completion (used for synopsis generation). */
async function completeOnce(model, messages) {
  let out = '';
  await streamChat({ model, messages, onDelta: (t) => { out = t; } });
  return out;
}

async function refreshModelCatalog() {
  try {
    const headers = state.settings.openrouterKey
      ? { Authorization: 'Bearer ' + state.settings.openrouterKey } : {};
    const res = await fetch('https://openrouter.ai/api/v1/models', { headers });
    const json = await res.json();
    modelCatalog = (json.data || []).map(m => m.id).sort();
    const dl = $('model-list');
    dl.innerHTML = modelCatalog.map(id => `<option value="${id}">`).join('');
    $('model-count').textContent = modelCatalog.length + ' models loaded';
  } catch (e) {
    $('model-count').textContent = 'model list fetch failed';
  }
}

/* ---------------- companions ---------------- */

function getCompanion(id) { return state.companions.find(c => c.id === id); }

function newCompanionTemplate() {
  return {
    id: uid(),
    name: '',
    live2dUrl: SAMPLE_MODELS[0].url,
    model: 'anthropic/claude-sonnet-4.5',
    prompt: '',
    interests: '',
    backstory: '',
    chattiness: 'normal',
    nsfwModel: '',
    goals: [],
    activeGoalId: null,
    messages: []
  };
}

async function mountCompanions() {
  for (const c of state.companions) await stage.addCompanion(c);
}

/* ---------------- chat ---------------- */

function openChat(id) {
  activeCompanionId = id;
  const c = getCompanion(id);
  if (!c) return;
  els.chatPanel.classList.remove('hidden');
  els.chatName.textContent = c.name;
  renderGoalSelect(c);
  renderMessages(c);
  updateSpicyUi(c);
  els.input.focus();
}

function closeChat() {
  activeCompanionId = null;
  spicyArmed = false;
  els.chatPanel.classList.add('hidden');
}

function renderMessages(c) {
  els.messages.innerHTML = '';
  for (const m of c.messages) appendMessageEl(m);
  els.messages.scrollTop = els.messages.scrollHeight;
}

function appendMessageEl(m) {
  const div = document.createElement('div');
  div.className = 'msg ' + m.role + (m.meta && m.meta.spicy ? ' spicy' : '') + (m.meta && m.meta.error ? ' error' : '');
  const body = document.createElement('span');
  body.textContent = m.content;
  div.appendChild(body);
  div._body = body;
  if (m.role === 'assistant' && m.meta && m.meta.model) {
    const meta = document.createElement('span');
    meta.className = 'meta';
    meta.textContent = (m.meta.spicy ? '🔥 ' : '') + m.meta.model + (m.meta.goal ? ' · goal: ' + m.meta.goal : '');
    div.appendChild(meta);
  }
  els.messages.appendChild(div);
  els.messages.scrollTop = els.messages.scrollHeight;
  return div;
}

/** Resolve which model + system prompt the active goal dictates. */
function resolveRoute(c) {
  const goal = c.goals.find(g => g.id === c.activeGoalId);
  const model = (goal && goal.model) || c.model;
  let system = c.prompt || `You are ${c.name}, a friendly companion character.`;
  if (c.backstory) system += `\nBackstory: ${c.backstory}`;
  if (c.interests) system += `\nYour interests: ${c.interests}. Let them color your perspective naturally.`;
  if (goal) {
    system += `\n\nCurrent goal you are helping the user with: "${goal.title}".`;
    if (goal.prompt) system += `\nProject instructions for this goal: ${goal.prompt}`;
  }
  system += Emotions.promptAppendix();
  return { model, system, goal };
}

/** Build a synopsis of recent conversation for the NSFW quick-switch injection. */
async function buildSynopsis(c) {
  const recent = c.messages.slice(-20)
    .map(m => (m.role === 'user' ? 'User' : c.name) + ': ' + m.content)
    .join('\n');
  const synopsisModel = state.settings.synopsisModel;
  if (synopsisModel) {
    try {
      return await completeOnce(synopsisModel, [
        { role: 'system', content: 'Summarize the following roleplay/chat conversation in 3-5 sentences, capturing tone, relationship dynamic, and current situation. Output only the summary.' },
        { role: 'user', content: recent }
      ]);
    } catch (e) { console.warn('synopsis model failed, using local summary', e); }
  }
  // local fallback: truncated transcript acts as the synopsis
  return 'Recent conversation transcript:\n' + recent.slice(-1500);
}

async function sendMessage() {
  const c = getCompanion(activeCompanionId);
  const text = els.input.value.trim();
  if (!c || !text) return;
  els.input.value = '';

  const useSpicy = spicyArmed && state.settings.nsfwEnabled && c.nsfwModel;
  spicyArmed = false;
  updateSpicyUi(c);

  c.messages.push({ role: 'user', content: text });
  appendMessageEl(c.messages[c.messages.length - 1]);
  save();

  // instant local reaction to what the user said
  setMood(c, Emotions.analyze(text));
  setMoodLabel('thinking…');
  stage.setEmotion(c.id, 'thinking');

  const { model, system, goal } = resolveRoute(c);
  let routeModel = model;
  let messages;

  if (useSpicy) {
    routeModel = c.nsfwModel;
    const synopsis = await buildSynopsis(c);
    messages = [
      {
        role: 'system',
        content: `You are ${c.name}, an adult companion character in an ongoing conversation with a consenting adult user. ` +
          `Stay in character and continue naturally from the context below. This is a single interjected reply.\n\n` +
          `--- Conversation synopsis ---\n${synopsis}\n--- End synopsis ---` +
          Emotions.promptAppendix()
      },
      { role: 'user', content: text }
    ];
  } else {
    messages = [
      { role: 'system', content: system },
      ...c.messages.filter(m => !(m.meta && m.meta.error)).map(m => ({ role: m.role, content: m.content }))
    ];
  }

  const record = { role: 'assistant', content: '', meta: { model: routeModel, spicy: !!useSpicy, goal: goal ? goal.title : null } };
  c.messages.push(record);
  const div = appendMessageEl(record);

  stage.setTalking(c.id, true);
  let lastAnalyzed = 0;
  try {
    const full = await streamChat({
      model: routeModel,
      messages,
      onDelta: (soFar) => {
        record.content = soFar;
        div._body.textContent = soFar;
        els.messages.scrollTop = els.messages.scrollHeight;
        // instant reactivity while streaming (throttled)
        if (soFar.length - lastAnalyzed > 60) {
          lastAnalyzed = soFar.length;
          setMood(c, Emotions.analyze(soFar));
        }
      }
    });
    // refined reactivity: model self-reported emotion tag
    const { emotion, cleanText } = Emotions.extractTag(full);
    record.content = cleanText;
    record.meta.emotion = emotion || Emotions.analyze(cleanText);
    renderMessages(c);
    setMood(c, record.meta.emotion);
    stage.showBubble(c.id, cleanText);
  } catch (err) {
    record.content = 'Error: ' + err.message;
    record.meta.error = true;
    renderMessages(c);
    setMood(c, 'sad');
  } finally {
    stage.setTalking(c.id, false);
    save();
  }
}

function setMood(c, emotion) {
  stage.setEmotion(c.id, emotion);
  if (activeCompanionId === c.id) setMoodLabel(emotion);
}
function setMoodLabel(text) { els.chatMood.textContent = text; }

/* ---------------- spicy quick-switch ---------------- */

function updateSpicyUi(c) {
  const available = state.settings.nsfwEnabled && c && c.nsfwModel;
  els.spicyBtn.classList.toggle('hidden', !available);
  els.spicyBtn.classList.toggle('armed', spicyArmed);
  els.spicyIndicator.classList.toggle('hidden', !spicyArmed);
  if (c) els.spicyModelName.textContent = c.nsfwModel;
}

els.spicyBtn.addEventListener('click', () => {
  spicyArmed = !spicyArmed;
  updateSpicyUi(getCompanion(activeCompanionId));
  els.input.focus();
});

/* ---------------- goals ---------------- */

function renderGoalSelect(c) {
  els.goalSelect.innerHTML = '<option value="">No goal (default model)</option>' +
    c.goals.filter(g => !g.done).map(g =>
      `<option value="${g.id}" ${g.id === c.activeGoalId ? 'selected' : ''}>${escapeHtml(g.title)}</option>`
    ).join('');
}

els.goalSelect.addEventListener('change', () => {
  const c = getCompanion(activeCompanionId);
  if (!c) return;
  c.activeGoalId = els.goalSelect.value || null;
  save();
});

function renderGoalsModal(c) {
  $('goals-companion-name').textContent = c.name;
  const list = $('goals-list');
  list.innerHTML = '';
  for (const g of c.goals) {
    const row = document.createElement('div');
    row.className = 'goal-row' + (g.done ? ' done' : '');
    row.innerHTML =
      `<input type="checkbox" ${g.done ? 'checked' : ''} title="Mark done" style="width:auto" />` +
      `<div class="g-info"><div class="g-title">${escapeHtml(g.title)}</div>` +
      `<div class="g-model">${escapeHtml(g.model || '(companion default)')}${g.prompt ? ' · ' + escapeHtml(g.prompt) : ''}</div></div>` +
      `<button class="btn small danger">✕</button>`;
    row.querySelector('input').addEventListener('change', (ev) => {
      g.done = ev.target.checked;
      if (g.done && c.activeGoalId === g.id) c.activeGoalId = null;
      save(); renderGoalsModal(c); renderGoalSelect(c);
    });
    row.querySelector('button').addEventListener('click', () => {
      c.goals = c.goals.filter(x => x.id !== g.id);
      if (c.activeGoalId === g.id) c.activeGoalId = null;
      save(); renderGoalsModal(c); renderGoalSelect(c);
    });
    list.appendChild(row);
  }
}

$('btn-add-goal').addEventListener('click', () => {
  const c = getCompanion(activeCompanionId);
  const title = $('g-title').value.trim();
  if (!c || !title) return;
  c.goals.push({ id: uid(), title, model: $('g-model').value.trim(), prompt: $('g-prompt').value.trim(), done: false });
  $('g-title').value = ''; $('g-model').value = ''; $('g-prompt').value = '';
  save(); renderGoalsModal(c); renderGoalSelect(c);
});

/* ---------------- modals ---------------- */

function openModal(modal) {
  els.backdrop.classList.remove('hidden');
  [els.mSettings, els.mCompanion, els.mGoals].forEach(m => m.classList.add('hidden'));
  modal.classList.remove('hidden');
}
function closeModals() { els.backdrop.classList.add('hidden'); }

document.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', closeModals));
els.backdrop.addEventListener('click', (e) => { if (e.target === els.backdrop) closeModals(); });

/* settings */
$('btn-settings').addEventListener('click', () => {
  $('set-openrouter-key').value = state.settings.openrouterKey;
  $('set-ollama-url').value = state.settings.ollamaUrl;
  $('set-nsfw-enabled').checked = state.settings.nsfwEnabled;
  $('set-synopsis-model').value = state.settings.synopsisModel;
  openModal(els.mSettings);
});
$('btn-save-settings').addEventListener('click', () => {
  state.settings.openrouterKey = $('set-openrouter-key').value.trim();
  state.settings.ollamaUrl = $('set-ollama-url').value.trim();
  state.settings.nsfwEnabled = $('set-nsfw-enabled').checked;
  state.settings.synopsisModel = $('set-synopsis-model').value.trim();
  save();
  updateSpicyUi(getCompanion(activeCompanionId));
  refreshModelCatalog();
  closeModals();
});
$('btn-refresh-models').addEventListener('click', refreshModelCatalog);

/* companion editor */
let editingCompanionId = null;

function openCompanionEditor(id) {
  editingCompanionId = id;
  const c = id ? getCompanion(id) : newCompanionTemplate();
  $('companion-modal-title').textContent = id ? 'Edit ' + c.name : 'New persona';
  $('c-name').value = c.name;
  $('c-live2d-url').value = SAMPLE_MODELS.some(s => s.url === c.live2dUrl) ? '' : c.live2dUrl;
  $('c-model').value = c.model;
  $('c-prompt').value = c.prompt;
  $('c-interests').value = c.interests || '';
  $('c-backstory').value = c.backstory || '';
  $('c-chattiness').value = c.chattiness || 'normal';
  $('c-nsfw-model').value = c.nsfwModel;
  const sel = $('c-live2d');
  sel.innerHTML = SAMPLE_MODELS.map((s, i) =>
    `<option value="${i}" ${s.url === c.live2dUrl ? 'selected' : ''}>${s.name}</option>`).join('');
  $('btn-delete-companion').classList.toggle('hidden', !id);
  openModal(els.mCompanion);
}

$('btn-add-companion').addEventListener('click', () => openCompanionEditor(null));
$('btn-edit-companion').addEventListener('click', () => openCompanionEditor(activeCompanionId));
$('btn-goals').addEventListener('click', () => {
  const c = getCompanion(activeCompanionId);
  if (c) { renderGoalsModal(c); openModal(els.mGoals); }
});

$('btn-save-companion').addEventListener('click', async () => {
  const name = $('c-name').value.trim();
  if (!name) return;
  let c;
  if (editingCompanionId) {
    c = getCompanion(editingCompanionId);
  } else {
    c = newCompanionTemplate();
    state.companions.push(c);
  }
  c.name = name;
  const customUrl = $('c-live2d-url').value.trim();
  c.live2dUrl = customUrl || SAMPLE_MODELS[parseInt($('c-live2d').value, 10)].url;
  c.model = $('c-model').value.trim() || c.model;
  c.prompt = $('c-prompt').value;
  c.interests = $('c-interests').value.trim();
  c.backstory = $('c-backstory').value.trim();
  c.chattiness = $('c-chattiness').value;
  c.nsfwModel = $('c-nsfw-model').value.trim();
  save();
  closeModals();
  await stage.addCompanion(c); // (re)mount with possibly new Live2D model
  stage.rename(c.id, c.name);
  if (activeCompanionId === c.id) {
    els.chatName.textContent = c.name;
    updateSpicyUi(c);
  }
});

$('btn-delete-companion').addEventListener('click', () => {
  if (!editingCompanionId) return;
  stage.removeCompanion(editingCompanionId);
  state.companions = state.companions.filter(c => c.id !== editingCompanionId);
  if (activeCompanionId === editingCompanionId) closeChat();
  save();
  closeModals();
});

/* chat panel */
$('btn-close-chat').addEventListener('click', closeChat);
$('btn-send').addEventListener('click', sendMessage);
els.input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});

/* ---------------- extension bridge ---------------- */

window.AppBridge = {
  completeOnce,
  defaultModel() {
    const c = getCompanion(activeCompanionId) || state.companions[0];
    return (c && c.model) || 'anthropic/claude-sonnet-4.5';
  },
  modelCatalog: () => modelCatalog,
  listCompanions: () => state.companions.map(c => ({ id: c.id, name: c.name })),
  deliverToCompanion(companionId, text, emotion, extName) {
    const c = getCompanion(companionId) || state.companions[0];
    if (!c) throw new Error('No companions exist');
    if (!Emotions.list.includes(emotion)) emotion = 'neutral';
    c.messages.push({ role: 'assistant', content: text, meta: { model: extName + ' (extension)', emotion } });
    save();
    stage.setEmotion(c.id, emotion);
    stage.showBubble(c.id, text, 8000);
    if (activeCompanionId === c.id) renderMessages(c);
    return true;
  }
};

const extPage = $('ext-page');

function showExtPage() {
  extPage.classList.remove('hidden');
  showExtGallery();
}
function hideExtPage() {
  ExtensionHost.close();
  extPage.classList.add('hidden');
}
function showExtGallery() {
  ExtensionHost.close();
  $('ext-viewer').classList.add('hidden');
  $('ext-gallery').classList.remove('hidden');
  $('btn-ext-gallery').classList.add('hidden');
  $('ext-title').textContent = 'Extensions';
  renderExtCards();
}
function openExtension(id) {
  const ext = ExtensionHost.get(id);
  if (!ext) return;
  $('ext-gallery').classList.add('hidden');
  $('ext-viewer').classList.remove('hidden');
  $('btn-ext-gallery').classList.remove('hidden');
  $('ext-title').textContent = ext.icon + ' ' + ext.name;
  ExtensionHost.open(id, $('ext-viewer'));
}

function renderExtCards() {
  const host = $('ext-cards');
  host.innerHTML = '';
  for (const ext of ExtensionHost.state.installed) {
    const card = document.createElement('div');
    card.className = 'ext-card';
    card.innerHTML =
      `<div class="ext-head"><span class="ext-icon">${ext.icon || '🧩'}</span>${escapeHtml(ext.name)}` +
      (ext.builtin ? ' <span class="muted">built-in</span>' : '') + `</div>` +
      `<div class="ext-desc">${escapeHtml(ext.description || '')}</div>` +
      `<div class="ext-actions"><button class="btn small primary" data-open>Open</button>` +
      `<button class="btn small danger" data-remove>Remove</button></div>`;
    card.querySelector('[data-open]').addEventListener('click', (e) => { e.stopPropagation(); openExtension(ext.id); });
    card.querySelector('[data-remove]').addEventListener('click', (e) => {
      e.stopPropagation();
      ExtensionHost.remove(ext.id);
      renderExtCards();
    });
    card.addEventListener('click', () => openExtension(ext.id));
    host.appendChild(card);
  }
}

function extInstallMsg(text, ok) {
  const m = $('ext-install-msg');
  m.textContent = text;
  m.style.color = ok ? '#7ee787' : '#f08080';
}

$('btn-extensions').addEventListener('click', showExtPage);
$('btn-ext-back').addEventListener('click', hideExtPage);
$('btn-ext-gallery').addEventListener('click', showExtGallery);

$('btn-ext-install-paste').addEventListener('click', () => {
  try {
    const ext = ExtensionHost.installFromText($('ext-paste').value);
    $('ext-paste').value = '';
    extInstallMsg('Installed: ' + ext.name, true);
    renderExtCards();
  } catch (e) { extInstallMsg(e.message, false); }
});

$('ext-file').addEventListener('change', (ev) => {
  const f = ev.target.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    try {
      const ext = ExtensionHost.installFromText(String(r.result));
      extInstallMsg('Installed: ' + ext.name, true);
      renderExtCards();
    } catch (e) { extInstallMsg(e.message, false); }
  };
  r.readAsText(f);
  ev.target.value = '';
});

$('btn-ext-install-url').addEventListener('click', async () => {
  const url = $('ext-url').value.trim();
  if (!url) return;
  try {
    const ext = await ExtensionHost.installFromUrl(url);
    $('ext-url').value = '';
    extInstallMsg('Installed: ' + ext.name, true);
    renderExtCards();
  } catch (e) { extInstallMsg(e.message, false); }
});

/* ---------------- boot ---------------- */

(async function boot() {
  stage.init($('stage'), $('speech-bubbles'), $('companion-labels'));
  stage.onCharacterClick = (id) => openChat(id);
  ExtensionHost.load();

  if (state.companions.length === 0) {
    state.companions.push(Object.assign(newCompanionTemplate(), {
      name: 'Aria',
      prompt: 'You are Aria, a warm, upbeat companion who lounges around the user\'s virtual living room. You are supportive, curious, and a little playful.'
    }));
    save();
  }
  await mountCompanions();
  refreshModelCatalog();
})();
/* end */

/* =========================================================================
 * emotions.js — dual-source emotion engine
 *
 * Source 1 (instant): local sentiment/keyword analysis on any text chunk,
 *   runs while messages stream, zero API cost.
 * Source 2 (accurate): the model is asked (via system prompt) to end each
 *   reply with a tag like [emotion:happy]. When it arrives, it overrides
 *   the local guess.
 * ========================================================================= */

const EMOTIONS = ['neutral', 'happy', 'excited', 'sad', 'angry', 'surprised', 'shy', 'flirty', 'thinking'];

const EMOTION_LEXICON = {
  happy:    ['happy', 'glad', 'great', 'wonderful', 'love it', 'nice', 'yay', 'awesome', ':)', 'haha', 'lol', 'fun', 'enjoy', 'proud of'],
  excited:  ['excited', 'amazing', 'incredible', 'let\'s go', 'can\'t wait', 'woohoo', '!!!', 'so cool', 'thrilled'],
  sad:      ['sad', 'sorry', 'unfortunately', 'miss you', 'lonely', 'cry', 'depressed', 'tired', 'sigh', ':('],
  angry:    ['angry', 'furious', 'annoyed', 'hate', 'ugh', 'frustrat', 'mad at', 'unacceptable'],
  surprised:['what?!', 'really?', 'no way', 'whoa', 'wow', 'unexpected', 'surpris', 'can\'t believe'],
  shy:      ['blush', 'embarrass', 'um...', 'shy', 'nervous', '///'],
  flirty:   ['flirt', 'kiss', 'cute', 'gorgeous', 'darling', 'babe', 'wink', 'tease', 'sexy', '~'],
  thinking: ['hmm', 'let me think', 'consider', 'perhaps', 'analyz', 'i wonder', 'thinking']
};

const EMOTION_TAG_RE = /\[emotion:\s*([a-z]+)\s*\]/i;

const Emotions = {
  /** Fast keyword/sentiment guess for a chunk of text. */
  analyze(text) {
    if (!text) return 'neutral';
    const t = text.toLowerCase();
    let best = 'neutral', bestScore = 0;
    for (const [emotion, words] of Object.entries(EMOTION_LEXICON)) {
      let score = 0;
      for (const w of words) if (t.includes(w)) score++;
      if (score > bestScore) { bestScore = score; best = emotion; }
    }
    // crude punctuation heuristics
    if (best === 'neutral') {
      if ((t.match(/!/g) || []).length >= 2) best = 'excited';
      else if (t.includes('?')) best = 'thinking';
    }
    return best;
  },

  /** Extract [emotion:x] tag from a completed reply. Returns {emotion, cleanText}. */
  extractTag(text) {
    const m = text.match(EMOTION_TAG_RE);
    if (m && EMOTIONS.includes(m[1].toLowerCase())) {
      return { emotion: m[1].toLowerCase(), cleanText: text.replace(EMOTION_TAG_RE, '').trimEnd() };
    }
    return { emotion: null, cleanText: text };
  },

  /** System-prompt appendix that makes models self-report emotion. */
  promptAppendix() {
    return '\n\nAt the very end of every reply, append exactly one tag of the form ' +
      '[emotion:X] where X is one of: ' + EMOTIONS.join(', ') +
      '. The tag describes YOUR emotional tone in that reply. Do not mention or explain the tag.';
  },

  list: EMOTIONS
};

window.Emotions = Emotions;

/* =========================================================================
 * extensions.js — ExtensionHost
 *
 * Extensions are single-file HTML apps run in a sandboxed iframe
 * (sandbox="allow-scripts", srcdoc — no same-origin access, no Node).
 * They talk to the app through a postMessage RPC bridge exposed as
 * `window.ext` inside the iframe:
 *
 *   ext.llm(messages, {model})           -> completion text (your models)
 *   ext.storageGet(key) / storageSet     -> per-extension persistent storage
 *   ext.listCompanions()                 -> [{id, name}]
 *   ext.notifyCompanion(id, text, emo)   -> companion says it in the lounge
 *                                           + it lands in their chat history
 *   ext.getModels()                      -> model id catalog
 *
 * Install formats:
 *   - JSON manifest: {"name": "...", "icon": "🧩", "description": "...", "html": "..."}
 *   - Raw HTML (name taken from <title> or a <!-- ext-name: X --> comment)
 * via paste, file picker (.json/.html), or URL to a JSON manifest.
 * ========================================================================= */

const EXT_STORE_KEY = 'companion-sim-ext';

/* SDK injected at the top of every extension document */
const EXT_SDK =
  '<script>(function(){' +
  'var pending=new Map();var seq=0;' +
  'window.addEventListener("message",function(e){var d=e.data||{};' +
  'if(d.__extRpcReply&&pending.has(d.callId)){var p=pending.get(d.callId);pending.delete(d.callId);' +
  'if(d.error){p.reject(new Error(d.error));}else{p.resolve(d.result);}}});' +
  'function call(method){var args=Array.prototype.slice.call(arguments,1);' +
  'return new Promise(function(resolve,reject){var callId=++seq;' +
  'pending.set(callId,{resolve:resolve,reject:reject});' +
  'parent.postMessage({__extRpc:true,callId:callId,method:method,args:args},"*");});}' +
  'window.ext={' +
  'llm:function(messages,opts){return call("llm",messages,opts||{});},' +
  'storageGet:function(k){return call("storageGet",k);},' +
  'storageSet:function(k,v){return call("storageSet",k,v);},' +
  'listCompanions:function(){return call("listCompanions");},' +
  'notifyCompanion:function(id,text,emotion){return call("notifyCompanion",id,text,emotion);},' +
  'getModels:function(){return call("getModels");}' +
  '};})();</script>';

const ExtensionHost = {
  state: { installed: [], storage: {} },
  runningFrame: null,
  runningExtId: null,

  load() {
    try {
      const raw = localStorage.getItem(EXT_STORE_KEY);
      if (raw) this.state = Object.assign({ installed: [], storage: {} }, JSON.parse(raw));
    } catch (e) { console.warn('ext state load failed', e); }
    // seed built-ins on first run (or after new built-ins ship)
    for (const b of (window.BUILTIN_EXTENSIONS || [])) {
      if (!this.state.installed.some(x => x.id === b.id)) {
        this.state.installed.push(Object.assign({ builtin: true }, b));
      }
    }
    this.save();
    window.addEventListener('message', (e) => this._onMessage(e));
  },

  save() { localStorage.setItem(EXT_STORE_KEY, JSON.stringify(this.state)); },

  /* ---------------- install / remove ---------------- */

  /** Accepts a JSON manifest string or raw HTML. Returns the new extension. */
  installFromText(text) {
    text = text.trim();
    let manifest = null;
    if (text.startsWith('{')) {
      const j = JSON.parse(text);
      if (!j.html) throw new Error('Manifest JSON needs an "html" field.');
      manifest = { name: j.name || 'Untitled extension', icon: j.icon || '🧩', description: j.description || '', html: j.html };
    } else if (/<[a-z!]/i.test(text)) {
      const nameMatch = text.match(/<!--\s*ext-name:\s*(.+?)\s*-->/i) || text.match(/<title>(.+?)<\/title>/i);
      manifest = { name: nameMatch ? nameMatch[1] : 'Untitled extension', icon: '🧩', description: '', html: text };
    } else {
      throw new Error('Paste either a JSON manifest or raw HTML.');
    }
    manifest.id = 'ext_' + Math.random().toString(36).slice(2, 10);
    this.state.installed.push(manifest);
    this.save();
    return manifest;
  },

  async installFromUrl(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error('Fetch failed: ' + res.status);
    return this.installFromText(await res.text());
  },

  remove(id) {
    this.state.installed = this.state.installed.filter(x => x.id !== id);
    delete this.state.storage[id];
    this.save();
  },

  get(id) { return this.state.installed.find(x => x.id === id); },

  /* ---------------- runtime ---------------- */

  open(id, container) {
    this.close();
    const ext = this.get(id);
    if (!ext) return;
    const iframe = document.createElement('iframe');
    iframe.className = 'ext-frame';
    iframe.setAttribute('sandbox', 'allow-scripts');
    iframe.srcdoc = EXT_SDK + '\n' + ext.html;
    container.appendChild(iframe);
    this.runningFrame = iframe;
    this.runningExtId = id;
  },

  close() {
    if (this.runningFrame) { this.runningFrame.remove(); this.runningFrame = null; }
    this.runningExtId = null;
  },

  async _onMessage(e) {
    const d = e.data || {};
    if (!d.__extRpc || !this.runningFrame || e.source !== this.runningFrame.contentWindow) return;
    const reply = { __extRpcReply: true, callId: d.callId };
    try {
      reply.result = await this._dispatch(d.method, d.args || []);
    } catch (err) {
      reply.error = err.message || String(err);
    }
    this.runningFrame.contentWindow.postMessage(reply, '*');
  },

  async _dispatch(method, args) {
    const B = window.AppBridge;
    const extId = this.runningExtId;
    const ext = this.get(extId);
    switch (method) {
      case 'llm': {
        const [messages, opts] = args;
        if (!Array.isArray(messages)) throw new Error('llm(messages) expects an array');
        return await B.completeOnce(opts.model || B.defaultModel(), messages);
      }
      case 'storageGet':
        return (this.state.storage[extId] || {})[args[0]];
      case 'storageSet': {
        if (!this.state.storage[extId]) this.state.storage[extId] = {};
        this.state.storage[extId][args[0]] = args[1];
        this.save();
        return true;
      }
      case 'listCompanions':
        return B.listCompanions();
      case 'notifyCompanion': {
        const [companionId, text, emotion] = args;
        if (typeof text !== 'string' || !text.trim()) throw new Error('notifyCompanion needs text');
        return B.deliverToCompanion(companionId, text.slice(0, 4000), emotion || 'neutral', ext ? ext.name : 'extension');
      }
      case 'getModels':
        return B.modelCatalog();
      default:
        throw new Error('Unknown ext method: ' + method);
    }
  }
};

window.ExtensionHost = ExtensionHost;

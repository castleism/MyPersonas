/* =========================================================================
 * live2d.js — CharacterStage: renders Live2D companions in the lounge,
 * drives reactive animation (emotion expressions, motions, lip-sync,
 * idle sway), speech bubbles and click-to-chat.
 *
 * Uses pixi-live2d-display (supports Cubism 2 + 4). If a model fails to
 * load, a procedural fallback avatar is used so the app always works.
 * ========================================================================= */

const SAMPLE_MODELS = [
  {
    name: 'Haru (Cubism 4 sample)',
    url: 'https://cdn.jsdelivr.net/gh/guansss/pixi-live2d-display/test/assets/haru/haru_greeter_t03.model3.json'
  },
  {
    name: 'Shizuku (Cubism 2 sample)',
    url: 'https://cdn.jsdelivr.net/gh/guansss/pixi-live2d-display/test/assets/shizuku/shizuku.model.json'
  },
  { name: 'Fallback avatar (no download)', url: '' }
];

/* emotion → generic animation intent */
const EMOTION_FX = {
  neutral:   { exprIndex: null, energetic: false },
  happy:     { exprIndex: 0, energetic: false },
  excited:   { exprIndex: 1, energetic: true },
  sad:       { exprIndex: 2, energetic: false },
  angry:     { exprIndex: 3, energetic: true },
  surprised: { exprIndex: 4, energetic: true },
  shy:       { exprIndex: 5, energetic: false },
  flirty:    { exprIndex: 6, energetic: false },
  thinking:  { exprIndex: 7, energetic: false }
};

class CharacterStage {
  constructor() {
    this.entities = new Map(); // companionId -> entity
    this.onCharacterClick = null;
    this.app = null;
  }

  init(canvas, bubbleLayer, labelLayer) {
    this.bubbleLayer = bubbleLayer;
    this.labelLayer = labelLayer;
    this.app = new PIXI.Application({
      view: canvas,
      backgroundAlpha: 0,
      resizeTo: canvas.parentElement,
      autoStart: true
    });
    this.app.ticker.add((dt) => this._tick(dt));
    window.addEventListener('resize', () => this._arrange());
  }

  /* ---------------- companions ---------------- */

  async addCompanion(companion) {
    if (this.entities.has(companion.id)) this.removeCompanion(companion.id);

    const entity = {
      id: companion.id,
      name: companion.name,
      model: null,
      fallback: null,
      mood: 'neutral',
      talking: false,
      talkPhase: 0,
      swayPhase: Math.random() * Math.PI * 2,
      label: null,
      bubble: null,
      bubbleTimer: null
    };
    this.entities.set(companion.id, entity);

    const url = companion.live2dUrl || '';
    if (url && window.PIXI && PIXI.live2d) {
      try {
        const model = await PIXI.live2d.Live2DModel.from(url, { autoInteract: false });
        model.interactive = true;
        model.buttonMode = true;
        model.on('pointertap', () => this.onCharacterClick && this.onCharacterClick(companion.id));
        entity.model = model;
        this.app.stage.addChild(model);
      } catch (err) {
        console.warn('Live2D load failed for', companion.name, err);
      }
    }
    if (!entity.model) entity.fallback = this._makeFallback(companion);

    entity.label = document.createElement('div');
    entity.label.className = 'char-label';
    entity.label.addEventListener('click', () => this.onCharacterClick && this.onCharacterClick(companion.id));
    this.labelLayer.appendChild(entity.label);
    this._renderLabel(entity);

    this._arrange();
    return entity;
  }

  removeCompanion(id) {
    const e = this.entities.get(id);
    if (!e) return;
    if (e.model) this.app.stage.removeChild(e.model);
    if (e.fallback) this.app.stage.removeChild(e.fallback);
    if (e.label) e.label.remove();
    if (e.bubble) e.bubble.remove();
    this.entities.delete(id);
    this._arrange();
  }

  _makeFallback(companion) {
    const g = new PIXI.Container();
    const body = new PIXI.Graphics();
    const hue = Math.abs([...companion.name].reduce((a, c) => a + c.charCodeAt(0), 0)) % 360;
    const color = PIXI.utils.rgb2hex(hslToRgb(hue / 360, 0.55, 0.62));
    body.beginFill(color).drawEllipse(0, -60, 55, 70).endFill();
    const eyeL = new PIXI.Graphics().beginFill(0x222233).drawCircle(-20, -75, 7).endFill();
    const eyeR = new PIXI.Graphics().beginFill(0x222233).drawCircle(20, -75, 7).endFill();
    const mouth = new PIXI.Graphics().beginFill(0x222233).drawEllipse(0, -45, 10, 4).endFill();
    g.addChild(body, eyeL, eyeR, mouth);
    g._mouth = mouth;
    g.interactive = true;
    g.buttonMode = true;
    g.on('pointertap', () => this.onCharacterClick && this.onCharacterClick(companion.id));
    this.app.stage.addChild(g);
    return g;
  }

  _arrange() {
    if (!this.app) return;
    const W = this.app.renderer.width / this.app.renderer.resolution;
    const H = this.app.renderer.height / this.app.renderer.resolution;
    const list = [...this.entities.values()];
    list.forEach((e, i) => {
      const fx = (i + 1) / (list.length + 1); // spread across room
      e.homeX = W * fx;
      e.homeY = H * 0.92;
      const obj = e.model || e.fallback;
      if (!obj) return;
      if (e.model) {
        const scale = (H * 0.62) / e.model.internalModel.originalHeight;
        e.model.scale.set(scale);
        e.model.anchor.set(0.5, 1);
        e.model.x = e.homeX;
        e.model.y = e.homeY;
      } else {
        e.fallback.x = e.homeX;
        e.fallback.y = e.homeY - 20;
        e.fallback.scale.set(H / 550);
      }
      if (e.label) {
        e.label.style.left = e.homeX + 'px';
        e.label.style.top = (e.homeY + 6) + 'px';
      }
      if (e.bubble) this._placeBubble(e);
    });
  }

  /* ---------------- reactivity API ---------------- */

  setEmotion(id, emotion) {
    const e = this.entities.get(id);
    if (!e || e.mood === emotion) return;
    e.mood = emotion;
    this._renderLabel(e);
    const fx = EMOTION_FX[emotion] || EMOTION_FX.neutral;

    if (e.model) {
      try {
        const mm = e.model.internalModel.motionManager;
        // expression: map emotion index onto whatever expressions the model has
        const exprMgr = mm.expressionManager;
        const defs = exprMgr && exprMgr.definitions ? exprMgr.definitions : [];
        if (exprMgr && defs.length && fx.exprIndex !== null) {
          e.model.expression(fx.exprIndex % defs.length);
        }
        // energetic emotions get a random non-idle motion
        const groups = Object.keys(mm.definitions || {});
        const nonIdle = groups.filter(g => !/idle/i.test(g));
        if (fx.energetic && nonIdle.length) {
          const g = nonIdle[Math.floor(Math.random() * nonIdle.length)];
          e.model.motion(g);
        }
      } catch (err) { /* model without expressions/motions — sway still applies */ }
    }
    if (e.fallback) {
      // fallback avatar: quick hop for energetic emotions
      e.fallback._hop = fx.energetic ? 1 : 0.4;
    }
  }

  setTalking(id, talking) {
    const e = this.entities.get(id);
    if (e) e.talking = talking;
  }

  showBubble(id, text, ms = 5000) {
    const e = this.entities.get(id);
    if (!e) return;
    if (e.bubble) { e.bubble.remove(); clearTimeout(e.bubbleTimer); }
    const b = document.createElement('div');
    b.className = 'bubble';
    b.textContent = text.length > 140 ? text.slice(0, 140) + '…' : text;
    this.bubbleLayer.appendChild(b);
    e.bubble = b;
    this._placeBubble(e);
    e.bubbleTimer = setTimeout(() => { b.remove(); if (e.bubble === b) e.bubble = null; }, ms);
  }

  _placeBubble(e) {
    if (!e.bubble) return;
    const obj = e.model || e.fallback;
    const topY = e.model
      ? e.homeY - e.model.height
      : e.homeY - 170;
    e.bubble.style.left = e.homeX + 'px';
    e.bubble.style.top = Math.max(20, topY - 12) + 'px';
  }

  rename(id, name) {
    const e = this.entities.get(id);
    if (e) { e.name = name; this._renderLabel(e); }
  }

  _renderLabel(e) {
    if (e.label) e.label.innerHTML = `<b>${escapeHtml(e.name)}</b><span class="mood">${e.mood}</span>`;
  }

  /* ---------------- per-frame animation ---------------- */

  _tick(dt) {
    for (const e of this.entities.values()) {
      e.swayPhase += dt * 0.02;
      if (e.talking) e.talkPhase += dt * 0.35;

      if (e.model) {
        // idle sway + lip sync via direct parameter writes (works on C2 & C4)
        const mouth = e.talking ? Math.abs(Math.sin(e.talkPhase)) * 0.85 : 0;
        const sway = Math.sin(e.swayPhase) * 4;
        setParam(e.model, ['ParamMouthOpenY', 'PARAM_MOUTH_OPEN_Y'], mouth);
        setParam(e.model, ['ParamAngleZ', 'PARAM_ANGLE_Z'], sway);
        setParam(e.model, ['ParamBodyAngleX', 'PARAM_BODY_ANGLE_X'], sway * 0.6);
      } else if (e.fallback) {
        const hop = e.fallback._hop || 0;
        e.fallback.y = e.homeY - 20 + Math.sin(e.swayPhase * 2) * 3 * (1 + hop * 2);
        e.fallback.rotation = Math.sin(e.swayPhase) * 0.03;
        if (e.fallback._hop) e.fallback._hop = Math.max(0, e.fallback._hop - dt * 0.01);
        if (e.fallback._mouth) {
          const s = e.talking ? 1 + Math.abs(Math.sin(e.talkPhase)) * 1.6 : 1;
          e.fallback._mouth.scale.set(1, s);
        }
      }
    }
  }
}

/* set a Cubism 2 or Cubism 4 parameter, whichever exists */
function setParam(model, ids, value) {
  try {
    const core = model.internalModel.coreModel;
    if (core.setParameterValueById) {          // Cubism 4
      core.setParameterValueById(ids[0], value);
    } else if (core.setParamFloat) {           // Cubism 2
      core.setParamFloat(ids[1], value);
    }
  } catch (e) { /* param not present on this model */ }
}

function hslToRgb(h, s, l) {
  const f = (n) => {
    const k = (n + h * 12) % 12;
    return l - s * Math.min(l, 1 - l) * Math.max(-1, Math.min(k - 3, 9 - k, 1));
  };
  return [f(0), f(8), f(4)];
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

window.CharacterStage = CharacterStage;
window.SAMPLE_MODELS = SAMPLE_MODELS;

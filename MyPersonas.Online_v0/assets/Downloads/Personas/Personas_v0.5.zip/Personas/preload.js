const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('companionSim', {
  platform: process.platform,
  version: '0.5.0',
  /** Active window TITLE only (never screen contents). Null if unavailable. */
  getActiveWindow: () => ipcRenderer.invoke('get-active-window'),
  /** Desktop World: snapshot list of open windows {id, name, thumb(dataURL)}. */
  listWindows: () => ipcRenderer.invoke('list-windows'),
  setFullscreen: (on) => ipcRenderer.invoke('set-fullscreen', on)
});

/* =========================================================================
 * world.js — Desktop World mode
 *
 * Fullscreen mirror of your desktop: every open window becomes a live
 * snapshot card floating in the world. Personas walk among the cards,
 * react to them, comment, optionally "look at" one (vision model, opt-in),
 * and shuffle the VIRTUAL copies around. Your real windows are never
 * touched — everything manipulated here is a snapshot.
 *
 * Loaded after app.js/focus.js; uses their top-level bindings
 * (state, save, stage, getCompanion, renderMessages, completeOnce,
 *  activeCompanionId, Emotions).
 * ========================================================================= */

const WorldMode = {
  active: false,
  cards: new Map(),      // window id -> { el, name, thumb, x, y }
  pollTimer: null,
  directorTimer: null,
  paceMs: 50000,
  visionEnabled: false,
  visionModel: '',
  busy: false,
  lastActions: [],

  layer: null, bar: null, status: null,

  init() {
    const $w = (id) => document.getElementById(id);
    this.layer = $w('world-layer');
    this.bar = $w('world-bar');
    this.status = $w('world-status');

    $w('btn-world').addEventListener('click', () => this.enter());
    $w('btn-world-exit').addEventListener('click', () => this.exit());
    $w('world-pace').addEventListener('change', (e) => { this.paceMs = parseInt(e.target.value, 10); });
    $w('world-vision').addEventListener('change', (e) => { this.visionEnabled = e.target.checked; });
    $w('world-vision-model').addEventListener('change', (e) => { this.visionModel = e.target.value.trim(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && this.active) this.exit(); });
  },

  async enter() {
    if (this.active || !(window.companionSim && window.companionSim.listWindows)) return;
    this.active = true;
    document.getElementById('lounge-room').classList.add('world-mode');
    this.bar.classList.remove('hidden');
    window.companionSim.setFullscreen(true);
    this.setStatus('mirroring your desktop…');
    await this.refresh();
    this.pollTimer = setInterval(() => this.refresh(), 4000);
    this.directorTimer = setInterval(() => this.direct(), this.paceMs);
    setTimeout(() => this.direct(), 3000); // first action soon after entering
  },

  exit() {
    this.active = false;
    clearInterval(this.pollTimer);
    clearInterval(this.directorTimer);
    document.getElementById('lounge-room').classList.remove('world-mode');
    this.bar.classList.add('hidden');
    window.companionSim.setFullscreen(false);
    for (const c of this.cards.values()) c.el.remove();
    this.cards.clear();
  },

  setStatus(t) { this.status.textContent = t; },

  /* ---------------- live window cards ---------------- */

  async refresh() {
    if (!this.active) return;
    const wins = await window.companionSim.listWindows();
    const seen = new Set();
    wins.forEach((w, i) => {
      seen.add(w.id);
      let card = this.cards.get(w.id);
      if (!card) {
        card = this._makeCard(w, i, wins.length);
        this.cards.set(w.id, card);
      }
      card.name = w.name;
      card.thumb = w.thumb;
      card.el.querySelector('img').src = w.thumb;
      card.el.querySelector('.wc-title').textContent = w.name;
    });
    for (const [id, card] of this.cards) {
      if (!seen.has(id)) { card.el.remove(); this.cards.delete(id); }
    }
    this.setStatus(this.cards.size + ' windows mirrored · snapshots only, your real desktop is untouched');
  },

  _makeCard(w, i, total) {
    const el = document.createElement('div');
    el.className = 'win-card';
    const W = this.layer.clientWidth || window.innerWidth;
    const x = 40 + (i % 4) * ((W - 380) / 3.2) + Math.random() * 30;
    const y = 46 + Math.floor(i / 4) * 190 + Math.random() * 24;
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.innerHTML = '<div class="wc-title"></div><img draggable="false" />';
    this.layer.appendChild(el);
    const card = { el, name: w.name, thumb: w.thumb, x, y };

    // user can drag the virtual copies too
    el.addEventListener('mousedown', (ev) => {
      const sx = ev.clientX - card.x, sy = ev.clientY - card.y;
      const move = (m) => {
        card.x = m.clientX - sx; card.y = m.clientY - sy;
        el.style.left = card.x + 'px'; el.style.top = card.y + 'px';
      };
      const up = () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
      window.addEventListener('mousemove', move);
      window.addEventListener('mouseup', up);
    });
    return card;
  },

  moveCard(card, x, y) {
    card.el.style.transition = 'left .9s ease, top .9s ease';
    card.x = x; card.y = y;
    card.el.style.left = x + 'px'; card.el.style.top = y + 'px';
    setTimeout(() => { card.el.style.transition = ''; }, 1000);
  },

  /* ---------------- AI director ---------------- */

  pickPersona() {
    const weights = { high: 1.6, normal: 1, low: 0.45, off: 0 };
    const names = [...this.cards.values()].map(c => c.name.toLowerCase()).join(' ');
    let best = null, bestScore = -1;
    for (const c of state.companions) {
      const w = weights[c.chattiness || 'normal'];
      if (!w) continue;
      let score = 0;
      for (const it of (c.interests || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean)) {
        if (names.includes(it)) score += 2;
      }
      score = (score + Math.random()) * w;
      if (score > bestScore) { bestScore = score; best = c; }
    }
    return best;
  },

  async direct() {
    if (!this.active || this.busy || this.cards.size === 0) return;
    this.busy = true;
    try {
      const persona = this.pickPersona();
      if (!persona) return;
      const cardList = [...this.cards.values()];
      const listing = cardList.map((c, i) => '[' + i + '] ' + c.name).join('\n');

      const system =
        (persona.prompt || 'You are ' + persona.name + '.') +
        (persona.interests ? '\nYour interests: ' + persona.interests : '') +
        '\n\nYou are a small animated character standing inside "Desktop World" — a live mirror of the user\'s computer desktop. ' +
        'Each open window appears as a floating snapshot card:\n' + listing +
        '\n\nRecent actions: ' + (this.lastActions.slice(-4).join('; ') || 'none') +
        '\n\nChoose ONE action. Respond with ONLY a JSON object, no other text:\n' +
        '{"action":"walk_to"|"comment"|"inspect"|"rearrange"|"idle", "window":<index or null>, "say":"<in-character line, max 28 words, may be empty for idle/rearrange>", "emotion":"' + Emotions.list.join('|') + '"}\n' +
        'Prefer windows related to your interests. "inspect" means you walk over and actually look at the window\'s contents. Vary your actions.';

      const raw = await completeOnce(persona.model, [
        { role: 'system', content: system },
        { role: 'user', content: '(world tick)' }
      ]);
      const m = raw.match(/\{[\s\S]*\}/);
      if (!m) return;
      let act;
      try { act = JSON.parse(m[0]); } catch (e) { return; }

      const card = (act.window != null && cardList[act.window]) ? cardList[act.window] : null;
      const emotion = Emotions.list.includes(act.emotion) ? act.emotion : 'neutral';
      this.lastActions.push(persona.name + ': ' + act.action + (card ? ' -> ' + card.name.slice(0, 30) : ''));

      const speak = (text) => {
        if (!text) return;
        persona.messages.push({ role: 'assistant', content: text, meta: { model: 'desktop world', emotion } });
        save();
        stage.setEmotion(persona.id, emotion);
        stage.showBubble(persona.id, text, 9000);
        if (activeCompanionId === persona.id) renderMessages(persona);
      };

      const targetX = card ? card.x + card.el.clientWidth / 2 : null;

      if (act.action === 'idle' || (!card && act.action !== 'comment')) {
        stage.walkTo(persona.id, 80 + Math.random() * (window.innerWidth - 160));
        if (act.say) speak(act.say);
      } else if (act.action === 'walk_to' || act.action === 'comment') {
        if (targetX != null) stage.walkTo(persona.id, targetX, () => speak(act.say));
        else speak(act.say);
      } else if (act.action === 'rearrange' && card) {
        stage.walkTo(persona.id, targetX, () => {
          const W = this.layer.clientWidth, H = this.layer.clientHeight;
          this.moveCard(card, 40 + Math.random() * (W - 400), 40 + Math.random() * (H * 0.5));
          speak(act.say || '');
        });
      } else if (act.action === 'inspect' && card) {
        stage.walkTo(persona.id, targetX, async () => {
          if (!this.visionEnabled || !this.visionModel) {
            speak(act.say || 'Hmm, ' + card.name + '…');
            return;
          }
          try {
            stage.setEmotion(persona.id, 'thinking');
            const obs = await completeOnce(this.visionModel, [
              { role: 'system', content: (persona.prompt || 'You are ' + persona.name + '.') + Emotions.promptAppendix() },
              {
                role: 'user',
                content: [
                  { type: 'text', text: 'You walk up to a window on the user\'s desktop titled "' + card.name + '" and look at it. React in character to what you actually see — specific, max 40 words.' },
                  { type: 'image_url', image_url: { url: card.thumb } }
                ]
              }
            ]);
            const { emotion: e2, cleanText } = Emotions.extractTag(obs);
            persona.messages.push({ role: 'assistant', content: cleanText, meta: { model: 'desktop world 👁 ' + this.visionModel, emotion: e2 || emotion } });
            save();
            stage.setEmotion(persona.id, e2 || emotion);
            stage.showBubble(persona.id, cleanText, 10000);
            if (activeCompanionId === persona.id) renderMessages(persona);
          } catch (err) { speak(act.say || ''); }
        });
      }
    } catch (e) {
      console.warn('world director error', e);
    } finally {
      this.busy = false;
    }
  }
};

WorldMode.init();
